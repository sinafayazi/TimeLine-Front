import { useState } from '@lynx-js/react'
import './App.css'

import { Header } from './components/Header.jsx'
import { CategoryButtons } from './components/CategoryButtons.jsx'
import { TimelineView } from './components/TimelineView.jsx'
import { BottomNavigation } from './components/BottomNavigation.jsx'
import { SelectionPage } from './pages/SelectionPage.jsx'

// Define the shape of event data
interface TimelineEvent {
  title: string;
  year: number;
}

// Define the shape for selected comparison data
interface ComparisonData {
  category1: { title: string; color: string; events: TimelineEvent[] };
  category2: { title: string; color: string; events: TimelineEvent[] };
}

// --- Dummy Data --- 
// (We'll move this or fetch it based on selection later)
const iranEvents: TimelineEvent[] = [
  { title: "Achaemenid Empire", year: 550 },
  { title: "Parthian Empire", year: 247 },
  { title: "Sasanian Empire", year: 224 },
  { title: "Samanid Empire", year: 819 },
  { title: "Safavid Empire", year: 1501 },
  { title: "Afsharid Dynasty", year: 1736 },
  { title: "Zand Dynasty", year: 1751 },
  { title: "Qajar Dynasty", year: 1789 },
  { title: "Pahlavi Dynasty", year: 1925 }
].sort((a, b) => a.year - b.year);

const islamicEvents: TimelineEvent[] = [
  { title: "Rise of Islam", year: 610 },
  { title: "Rashidun Caliphate", year: 632 },
  { title: "Umayyad Caliphate", year: 661 },
  { title: "Abbasid Caliphate", year: 750 },
  { title: "Fatimid Caliphate", year: 909 },
  { title: "Saladin Era", year: 1174 },
  { title: "Mamluk Sultanate", year: 1250 },
  { title: "Ottoman Empire", year: 1299 },
  { title: "Mughal Empire", year: 1526 }
].sort((a, b) => a.year - b.year);
// --- End Dummy Data ---

// Main App Component
export const App = () => {
  // State to manage the current view ('selection' or 'comparison')
  const [currentPage, setCurrentPage] = useState('selection'); // Start with selection page
  
  // State to hold the data for comparison (will be set by SelectionPage)
  const [comparisonData, setComparisonData] = useState<ComparisonData | null>(null);

  const itemHeight = 120; // Height of each timeline item
  const headerHeight = 120; // Approx height of header + category buttons
  const footerHeight = 80;  // Height of bottom navigation
  // Calculate viewport height dynamically if possible, otherwise estimate
  const viewportHeight = typeof window !== 'undefined' ? window.innerHeight - headerHeight - footerHeight : 600;

  // Function to be called by SelectionPage to start comparison
  const handleStartComparison = (data: ComparisonData) => {
    setComparisonData(data);
    setCurrentPage('comparison');
  };

  return (
    <view style={{ 
      width: "100%", 
      height: "100vh", 
      backgroundColor: "#FFFFFF", 
      display: "flex", 
      flexDirection: "column"
    }}>
      {currentPage === 'selection' ? (
        // Render Selection Page 
        <SelectionPage onStartComparison={handleStartComparison} />
      ) : comparisonData ? (
        // Render Comparison Page within a flex container
        <view style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
          <Header title="Timeline Comparison" />
          <CategoryButtons categories={[
            { title: comparisonData.category1.title, color: comparisonData.category1.color },
            { title: comparisonData.category2.title, color: comparisonData.category2.color },
          ]} />
          <TimelineView 
            iranEvents={comparisonData.category1.events}
            islamicEvents={comparisonData.category2.events}
            itemHeight={itemHeight}
            viewportHeight={viewportHeight} // TimelineView uses this height internally
          />
          <BottomNavigation />
        </view>
      ) : (
        // Fallback: Should ideally not happen if selection page logic is sound
        <SelectionPage onStartComparison={handleStartComparison} /> // Show selection again
      )}
    </view>
  );
};
