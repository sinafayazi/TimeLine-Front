import { useState } from '@lynx-js/react';
import type { ScrollEvent } from '@lynx-js/types';
import { TimelineItem } from './TimelineItem.jsx';

interface TimelineEvent {
  title: string;
  year: number;
}

interface TimelineViewProps {
  iranEvents: TimelineEvent[];
  islamicEvents: TimelineEvent[];
  itemHeight: number;
  viewportHeight: number;
}

export const TimelineView = ({ 
  iranEvents, 
  islamicEvents, 
  itemHeight, 
  viewportHeight 
}: TimelineViewProps) => {
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [scrollPosition, setScrollPosition] = useState(0);

  // Combine and sort all events chronologically
  const allEvents = [...iranEvents, ...islamicEvents].sort((a, b) => a.year - b.year);
  
  // Find the index of each event in the sorted timeline
  const getEventIndex = (year: number) => {
    return allEvents.findIndex(event => event.year === year);
  };

  const getScale = (index: number, scrollTop: number) => {
    const viewportCenter = scrollTop + (viewportHeight / 2);
    const itemCenter = (index * itemHeight) + (itemHeight / 2);
    const distanceFromCenter = Math.abs(viewportCenter - itemCenter);
    const scaleFactor = Math.max(0, 1 - (distanceFromCenter / (viewportHeight / 2)));
    return 0.6 + (0.4 * Math.pow(scaleFactor, 2));
  };

  const getOpacity = (index: number, scrollTop: number) => {
    const viewportCenter = scrollTop + (viewportHeight / 2);
    const itemCenter = (index * itemHeight) + (itemHeight / 2);
    const distanceFromCenter = Math.abs(viewportCenter - itemCenter);
    const opacityFactor = Math.max(0, 1 - (distanceFromCenter / (viewportHeight / 2)));
    return 0.4 + (0.6 * opacityFactor);
  };

  return (
    <view style={{ 
      flex: 1,
      position: "relative",
      overflow: "hidden",
      height: `${viewportHeight}px`
    }}>
      {/* Center Line */}
      <view style={{ 
        width: "2px", 
        backgroundColor: "#E0E0E0",
        position: "absolute",
        left: "50%",
        top: "0px",
        bottom: "0px",
        transform: "translateX(-50%)",
        zIndex: 1
      }} />

      {/* Scrollable Timeline */}
      <scroll-view
        scroll-y
        style={{ 
          height: "100%",
          overscrollBehavior: "contain"
        }}
        bindscroll={(event: ScrollEvent) => {
          const scrollTop = event.detail?.scrollTop || 0;
          setScrollPosition(scrollTop);
          const viewportCenter = scrollTop + (viewportHeight / 2);
          const index = Math.floor(viewportCenter / itemHeight);
          setSelectedIndex(index);
        }}
      >
        <view style={{ 
          padding: "0px 16px",
          paddingTop: `${itemHeight * 2}px`,
          paddingBottom: `${itemHeight * 2}px`,
          minHeight: `${itemHeight * (allEvents.length + 4)}px`
        }}>
          {iranEvents.map((event) => {
            const index = getEventIndex(event.year);
            return (
              <view key={`iran-${event.year}`} style={{ 
                position: "absolute",
                left: "0px",
                right: "50%",
                top: `${index * itemHeight}px`,
                height: `${itemHeight}px`,
                display: "flex",
                justifyContent: "flex-end",
                alignItems: "center",
                paddingRight: "20px",
                transition: "all 0.3s ease"
              }}>
                <TimelineItem 
                  title={event.title} 
                  year={event.year} 
                  color="#5FBFB0"
                  scale={getScale(index, scrollPosition)}
                  transformOrigin="right center"
                />
              </view>
            );
          })}

          {islamicEvents.map((event) => {
            const index = getEventIndex(event.year);
            return (
              <view key={`islamic-${event.year}`} style={{ 
                position: "absolute",
                left: "50%",
                right: "0px",
                top: `${index * itemHeight}px`,
                height: `${itemHeight}px`,
                display: "flex",
                justifyContent: "flex-start",
                alignItems: "center",
                paddingLeft: "20px",
                transition: "all 0.3s ease"
              }}>
                <TimelineItem 
                  title={event.title} 
                  year={event.year} 
                  color="#6B77C1"
                  scale={getScale(index, scrollPosition)}
                  transformOrigin="left center"
                />
              </view>
            );
          })}

          {/* Year Markers */}
          {allEvents.map((event, index) => (
            <text key={`year-${event.year}`} style={{
              position: "absolute",
              left: "50%",
              top: `${index * itemHeight + itemHeight/2}px`,
              transform: "translateX(-50%)",
              color: "#666666",
              fontSize: "14px",
              opacity: getOpacity(index, scrollPosition)
            }}>{event.year}</text>
          ))}
        </view>
      </scroll-view>
    </view>
  );
}; 