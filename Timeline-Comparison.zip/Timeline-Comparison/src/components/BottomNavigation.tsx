export const BottomNavigation = () => (
  <view style={{ 
    padding: "16px",
    borderTopWidth: "1px",
    borderTopColor: "#E0E0E0",
    backgroundColor: "#FFFFFF",
    display: "flex",
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    height: "80px"
  }}>
    {/* Replace with actual icons/buttons later */}
    <text style={{ color: "#666666", fontSize: "20px" }}>🏠</text>
    <text style={{ color: "#666666", fontSize: "20px" }}>⬇️</text>
    <text style={{ color: "#666666", fontSize: "20px" }}>🔍</text>
    <text style={{ color: "#666666", fontSize: "20px" }}>🔍</text>
    <text style={{ color: "#666666", fontSize: "20px" }}>☰</text>
  </view>
); 