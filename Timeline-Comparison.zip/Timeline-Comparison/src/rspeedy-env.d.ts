/// <reference types="@lynx-js/rspeedy/client" />
