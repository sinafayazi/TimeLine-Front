interface HeaderProps {
  title: string;
}

export const Header = ({ title }: HeaderProps) => (
  <view style={{ padding: "16px", marginTop: "40px" }}>
    <text style={{ 
      fontSize: "32px", 
      fontWeight: "bold", 
      marginBottom: "24px", 
      color: "black"
    }}>{title}</text>
  </view>
); 