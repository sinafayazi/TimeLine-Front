import { useState } from '@lynx-js/react';

// Define the shape of event data
interface TimelineEvent {
  title: string;
  year: number;
}

// Define the shape for selected comparison data
interface ComparisonData {
  category1: { title: string; color: string; events: TimelineEvent[] };
  category2: { title: string; color: string; events: TimelineEvent[] };
}

interface SelectionPageProps {
  onStartComparison: (data: ComparisonData) => void;
}

interface SubjectData {
  title: string;
  color: string;
  events: TimelineEvent[];
}

interface CategoryData {
  [subject: string]: SubjectData;
}

interface AvailableDataType {
  [category: string]: CategoryData;
}

// --- Dummy Data for Selection Options ---
const availableData: AvailableDataType = {
  "History": {
    "Iran": {
      title: "Iran History",
      color: "#5FBFB0",
      events: [
        { title: "Achaemenid Empire", year: 550 }, { title: "Parthian Empire", year: 247 }, { title: "Sasanian Empire", year: 224 }, { title: "Samanid Empire", year: 819 }, { title: "Safavid Empire", year: 1501 }, { title: "Afsharid Dynasty", year: 1736 }, { title: "Zand Dynasty", year: 1751 }, { title: "Qajar Dynasty", year: 1789 }, { title: "Pahlavi Dynasty", year: 1925 }
      ].sort((a, b) => a.year - b.year)
    },
    "Islam": {
      title: "Islamic History",
      color: "#6B77C1",
      events: [
        { title: "Rise of Islam", year: 610 }, { title: "Rashidun Caliphate", year: 632 }, { title: "Umayyad Caliphate", year: 661 }, { title: "Abbasid Caliphate", year: 750 }, { title: "Fatimid Caliphate", year: 909 }, { title: "Saladin Era", year: 1174 }, { title: "Mamluk Sultanate", year: 1250 }, { title: "Ottoman Empire", year: 1299 }, { title: "Mughal Empire", year: 1526 }
      ].sort((a, b) => a.year - b.year)
    }
  },
  "Art": {
    "Impressionism": {
      title: "Impressionism",
      color: "#FF9500",
      events: [
        { title: "Monet - Impression, soleil levant", year: 1872 }, { title: "First Impressionist Exhibition", year: 1874 }, { title: "Degas - The Absinthe Drinker", year: 1876 }, { title: "Renoir - Bal du moulin de la Galette", year: 1876 }, { title: "Caillebotte - Paris Street; Rainy Day", year: 1877 }, { title: "Morisot - Summer's Day", year: 1879 }, { title: "Pissarro - The Boulevard Montmartre", year: 1897 }
      ].sort((a, b) => a.year - b.year)
    },
    "Cubism": {
      title: "Cubism",
      color: "#FFCC00",
      events: [
        { title: "Picasso - Les Demoiselles d'Avignon", year: 1907 }, { title: "Braque - Houses at L'Estaque", year: 1908 }, { title: "Salon des Indépendants (Cubist room)", year: 1911 }, { title: "Gleizes & Metzinger - Du \"Cubisme\"", year: 1912 }, { title: "Gris - Portrait of Picasso", year: 1912 }, { title: "Léger - Contrast of Forms", year: 1913 }
      ].sort((a, b) => a.year - b.year)
    }
  },
  "Programming": {
    "Early Languages": {
      title: "Early Languages",
      color: "#34C759",
      events: [
        { title: "FORTRAN", year: 1957 }, { title: "LISP", year: 1958 }, { title: "COBOL", year: 1959 }, { title: "ALGOL", year: 1960 }, { title: "BASIC", year: 1964 }, { title: "PL/I", year: 1964 }, { title: "Pascal", year: 1970 }
      ].sort((a, b) => a.year - b.year)
    },
    "Modern Languages": {
      title: "Modern Languages",
      color: "#007AFF",
      events: [
        { title: "C++", year: 1985 }, { title: "Perl", year: 1987 }, { title: "Python", year: 1991 }, { title: "Java", year: 1995 }, { title: "JavaScript", year: 1995 }, { title: "PHP", year: 1995 }, { title: "C#", year: 2000 }, { title: "Go", year: 2009 }, { title: "Rust", year: 2010 }, { title: "Swift", year: 2014 }
      ].sort((a, b) => a.year - b.year)
    }
  }
};
// --- End Dummy Data ---

// Define type for picker-like event detail
interface PickerChangeEventDetail {
  value: number; // Index of the selected item
}

interface PickerChangeEvent {
  detail: PickerChangeEventDetail;
}

// Reusable Picker Simulation Component
interface PickerProps {
  label: string;
  options: string[];
  selectedValue: string;
  onSelect: (value: string) => void;
}

const SimplePicker = ({ label, options, selectedValue, onSelect }: PickerProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const selectedIndex = options.indexOf(selectedValue);

  return (
    <view>
      <text style={{ fontSize: "16px", color: "black", marginBottom: '4px' }}>{label}:</text>
      <view 
        style={{ border: '1px solid #ccc', padding: '8px', borderRadius: '4px', cursor: 'pointer' }}
        bindtap={() => setIsOpen(!isOpen)}
      >
        <text>{selectedValue}</text>
      </view>
      {isOpen && (
        <view style={{ border: '1px solid #ccc', borderRadius: '4px', marginTop: '4px', maxHeight: '150px', overflowY: 'auto' }}>
          {options.map((option, index) => (
            <view 
              key={option}
              style={{ padding: '8px', cursor: 'pointer', backgroundColor: index === selectedIndex ? '#eee' : 'white' }}
              bindtap={() => {
                onSelect(option);
                setIsOpen(false);
              }}
            >
              <text>{option}</text>
            </view>
          ))}
        </view>
      )}
    </view>
  );
};

export const SelectionPage = ({ onStartComparison }: SelectionPageProps) => {
  const [selectedCategoryKey1, setSelectedCategoryKey1] = useState("History");
  const [selectedSubjectKey1, setSelectedSubjectKey1] = useState("Iran");

  const [selectedCategoryKey2, setSelectedCategoryKey2] = useState("History");
  const [selectedSubjectKey2, setSelectedSubjectKey2] = useState("Islam");

  const handleCompareClick = () => {
    const subject1 = availableData[selectedCategoryKey1]?.[selectedSubjectKey1];
    const subject2 = availableData[selectedCategoryKey2]?.[selectedSubjectKey2];

    if (subject1 && subject2) {
      onStartComparison({
        category1: subject1,
        category2: subject2,
      });
    } else {
      console.error("Selected subjects not found in data.");
      // Handle error appropriately - maybe show a message to the user
    }
  };

  // Helper to get subjects for a selected category
  const getSubjectsForCategory = (categoryKey: string) => {
    return availableData[categoryKey] ? Object.keys(availableData[categoryKey]) : [];
  };

  return (
    <view style={{ padding: "16px", marginTop: "40px", display: "flex", flexDirection: "column", alignItems: "stretch", gap: "20px", flex: 1 }}>
      <text style={{ fontSize: "28px", fontWeight: "bold", color: "black", marginBottom: "20px", textAlign: "center" }}>Select Timelines to Compare</text>
      
      {/* --- Selection UI --- */}
      <view style={{ display: 'flex', flexDirection: 'row', gap: '16px', justifyContent: 'space-around' }}>
        {/* Column 1 Selection */}
        <view style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: '12px' }}>
          <text style={{ fontSize: "18px", color: "black", fontWeight: "bold", marginBottom: '8px' }}>Timeline 1</text>
          <SimplePicker 
            label="Category"
            options={Object.keys(availableData)}
            selectedValue={selectedCategoryKey1}
            onSelect={(newCategoryKey) => {
              setSelectedCategoryKey1(newCategoryKey);
              setSelectedSubjectKey1(Object.keys(availableData[newCategoryKey])[0]); // Reset subject
            }}
          />
          <SimplePicker 
            label="Subject"
            options={getSubjectsForCategory(selectedCategoryKey1)}
            selectedValue={selectedSubjectKey1}
            onSelect={setSelectedSubjectKey1}
          />
        </view>

        {/* Column 2 Selection */}
         <view style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: '12px' }}>
          <text style={{ fontSize: "18px", color: "black", fontWeight: "bold", marginBottom: '8px' }}>Timeline 2</text>
          <SimplePicker 
            label="Category"
            options={Object.keys(availableData)}
            selectedValue={selectedCategoryKey2}
            onSelect={(newCategoryKey) => {
              setSelectedCategoryKey2(newCategoryKey);
              setSelectedSubjectKey2(Object.keys(availableData[newCategoryKey])[0]); // Reset subject
            }}
          />
          <SimplePicker 
            label="Subject"
            options={getSubjectsForCategory(selectedCategoryKey2)}
            selectedValue={selectedSubjectKey2}
            onSelect={setSelectedSubjectKey2}
          />
        </view>
      </view>

      {/* --- Compare Button --- */}
      <view style={{ marginTop: 'auto', paddingBottom: '20px' }}>{/* Push button towards bottom */}
          <view 
            style={{ 
              padding: "16px 32px", 
              backgroundColor: "#007AFF", 
              borderRadius: "12px",
              cursor: "pointer"
            }}
            bindtap={handleCompareClick} // Use bindtap for click events
          >
            <text style={{ color: "white", fontSize: "20px", fontWeight: "bold", textAlign: "center" }}>Start Comparison</text>
          </view>
      </view>
    </view>
  );
}; 