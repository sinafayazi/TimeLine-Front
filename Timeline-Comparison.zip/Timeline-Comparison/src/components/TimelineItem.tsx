interface TimelineItemProps {
  title: string;
  year: number;
  color: string;
  scale?: number;
  transformOrigin?: string;
}

export const TimelineItem = ({ 
  title, 
  year, 
  color, 
  scale = 1, 
  transformOrigin = 'center' 
}: TimelineItemProps) => (
  <view style={{
    backgroundColor: color,
    padding: "16px",
    borderRadius: "12px",
    width: "180px",
    transform: `scale(${scale})`,
    transformOrigin,
    transition: "all 0.3s ease",
    opacity: Math.max(0.4, scale) // Keep opacity linked to scale for simplicity here
  }}>
    <text style={{ 
      color: 'white', 
      fontSize: "24px", 
      fontWeight: "bold",
      marginBottom: "4px"
    }}>{title}</text>
    <text style={{ 
      color: 'white', 
      fontSize: "20px"
    }}>{year}</text>
  </view>
); 