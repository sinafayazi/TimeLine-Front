interface CategoryButtonsProps {
  categories: { title: string; color: string }[];
}

export const CategoryButtons = ({ categories }: CategoryButtonsProps) => (
  <view style={{ 
    padding: "0px 16px",
    display: "flex",
    flexDirection: "row",
    gap: "12px",
    marginBottom: "24px"
  }}>
    {categories.map(category => (
      <view key={category.title} style={{ 
        backgroundColor: category.color, 
        padding: "16px",
        borderRadius: "32px",
        flex: "1"
      }}>
        <text style={{ 
          color: "white", 
          fontWeight: "bold", 
          fontSize: "20px",
          textAlign: "center"
        }}>{category.title}</text>
      </view>
    ))}
  </view>
); 